const text = 'Hello NodeJS from data.js'

module.exports = text